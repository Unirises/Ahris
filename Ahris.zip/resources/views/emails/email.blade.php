<!DOCTYPE html>
<html>
<head>
 <title>Laravel 8 Send Email Example</title>
</head>
<body>
 
 <h1>{{$email ?? '' }}</h1>
 <h1>{{$email ?? '' }}</h1>
 <p>thanks</p>
 
</body>
</html> 