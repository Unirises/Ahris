<div class="card mb-4">
    <!-- Card body -->
    <div class="card-body">
        <div class="col-sm text-center">
            <button type="button" data-toggle="modal"  data-target="#accountAddBusinessCustomer" class="btn btn-lg btn-primary mb-1">Add Bussiness Customer</button>
            <button type="button" data-toggle="modal"  data-target="#accountAddBusinessSupplier" class="btn btn-lg btn-secondary mb-1">Add Bussiness Supplier</button>
            <button type="button" data-toggle="modal" data-target="#accountAddIndividualCustomer" class="btn btn-lg btn-success mb-1">Add Individual Customer</button>
            <button type="button" data-toggle="modal" data-target="#accountAddIndividualSupplier" class="btn btn-lg btn-info mb-1">Add Individual Supplier</button>
        </div>
      </div>
  </div>
