<footer class="footer text-center pt-8 bottom-0 col-lg-12">
        <div class="row align-items-center">
          <div class="col-lg-12">
            <div class="copyright text-center text-lg-left text-muted pl-3">
              &copy; <?php echo date("Y"); ?> <a href="#" class="font-weight-bold ml-0">Ahris PH</a>
            </div>
          </div>
        </div>
      </footer>